/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intt.datenlogik;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dominik
 */
@Entity
@Table(name = "sales")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sales.findAll", query = "SELECT s FROM Sales s"),
    @NamedQuery(name = "Sales.findBySalesID", query = "SELECT s FROM Sales s WHERE s.salesID = :salesID"),
    @NamedQuery(name = "Sales.findByMenge", query = "SELECT s FROM Sales s WHERE s.menge = :menge")})
public class Sales implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "salesID")
    private Integer salesID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "menge")
    private int menge;
    @JoinColumn(name = "produktID", referencedColumnName = "produktID")
    @ManyToOne(optional = false)
    private Product produktID;
    @JoinColumn(name = "stationID", referencedColumnName = "stationID")
    @ManyToOne(optional = false)
    private Station stationID;

    public Sales() {
    }

    public Sales(Integer salesID) {
        this.salesID = salesID;
    }

    public Sales(Integer salesID, int menge) {
        this.salesID = salesID;
        this.menge = menge;
    }

    public Integer getSalesID() {
        return salesID;
    }

    public void setSalesID(Integer salesID) {
        this.salesID = salesID;
    }

    public int getMenge() {
        return menge;
    }

    public void setMenge(int menge) {
        this.menge = menge;
    }

    public Product getProduktID() {
        return produktID;
    }

    public void setProduktID(Product produktID) {
        this.produktID = produktID;
    }

    public Station getStationID() {
        return stationID;
    }

    public void setStationID(Station stationID) {
        this.stationID = stationID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (salesID != null ? salesID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sales)) {
            return false;
        }
        Sales other = (Sales) object;
        if ((this.salesID == null && other.salesID != null) || (this.salesID != null && !this.salesID.equals(other.salesID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "intt.datenlogik.Sales[ salesID=" + salesID + " ]";
    }
    
}
