/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intt.datenlogik;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dominik
 */
@Entity
@Table(name = "inventory")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Inventory.findAll", query = "SELECT i FROM Inventory i"),
    @NamedQuery(name = "Inventory.findByInventoryID", query = "SELECT i FROM Inventory i WHERE i.inventoryID = :inventoryID"),
    @NamedQuery(name = "Inventory.findByAktMenge", query = "SELECT i FROM Inventory i WHERE i.aktMenge = :aktMenge"),
    @NamedQuery(name = "Inventory.findByMinMenge", query = "SELECT i FROM Inventory i WHERE i.minMenge = :minMenge"),
    @NamedQuery(name = "Inventory.findBySollMenge", query = "SELECT i FROM Inventory i WHERE i.sollMenge = :sollMenge")})
public class Inventory implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "inventoryID")
    private Integer inventoryID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "aktMenge")
    private int aktMenge;
    @Basic(optional = false)
    @NotNull
    @Column(name = "minMenge")
    private int minMenge;
    @Basic(optional = false)
    @NotNull
    @Column(name = "sollMenge")
    private int sollMenge;
    @JoinColumn(name = "produktID", referencedColumnName = "produktID")
    @ManyToOne(optional = false)
    private Product produktID;
    @JoinColumn(name = "stationID", referencedColumnName = "stationID")
    @ManyToOne(optional = false)
    private Station stationID;

    public Inventory() {
    }

    public Inventory(Integer inventoryID) {
        this.inventoryID = inventoryID;
    }

    public Inventory(Integer inventoryID, int aktMenge, int minMenge, int sollMenge) {
        this.inventoryID = inventoryID;
        this.aktMenge = aktMenge;
        this.minMenge = minMenge;
        this.sollMenge = sollMenge;
    }

    public Integer getInventoryID() {
        return inventoryID;
    }

    public void setInventoryID(Integer inventoryID) {
        this.inventoryID = inventoryID;
    }

    public int getAktMenge() {
        return aktMenge;
    }

    public void setAktMenge(int aktMenge) {
        this.aktMenge = aktMenge;
    }

    public int getMinMenge() {
        return minMenge;
    }

    public void setMinMenge(int minMenge) {
        this.minMenge = minMenge;
    }

    public int getSollMenge() {
        return sollMenge;
    }

    public void setSollMenge(int sollMenge) {
        this.sollMenge = sollMenge;
    }

    public Product getProduktID() {
        return produktID;
    }

    public void setProduktID(Product produktID) {
        this.produktID = produktID;
    }

    public Station getStationID() {
        return stationID;
    }

    public void setStationID(Station stationID) {
        this.stationID = stationID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (inventoryID != null ? inventoryID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Inventory)) {
            return false;
        }
        Inventory other = (Inventory) object;
        if ((this.inventoryID == null && other.inventoryID != null) || (this.inventoryID != null && !this.inventoryID.equals(other.inventoryID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "intt.datenlogik.Inventory[ inventoryID=" + inventoryID + " ]";
    }
    
}
